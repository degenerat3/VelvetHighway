<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <title>The Velvet Highway</title>

    <link rel="stylesheet" href="css/style.css" />
    <style>
      body {
        background-image: url("images/background.png");
        color:#00e7ff;
      }
</style>
  </head>

  <header style="background-color:gray;background-image:none">
  <a href="index.php">
  <img src="images/vh-logo-full.png" alt="Velvet Highway Homepage" style="width:436px;height:100px;border:0;">
</a>
  <br>
  <a href="index.php">
  <img src="images/home.png"style="width:100px;height:25px;border:0;">
</a>
<a href="inventory.php">
  <img src="images/inventory.png"style="width:100px;height:25px;border:0;">
</a>
<a href="orders.php">
  <img src="images/orders.png" style="width:100px;height:25px;border:0;">
</a>
<a href="purchase.php">
  <img src="images/new-purchase.png" style="width:100px;height:25px;border:0;">
</a>
  </header>
</html>