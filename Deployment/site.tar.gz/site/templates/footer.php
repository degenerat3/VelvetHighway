<br>
<br>
<br>
<center>
<footer style="background-color:gray;background-image:none">
<hr style="height:1px;border-top:1px;visibility:hidden" />
</footer> 
<p>Disclaimer: This website is purposefully insecure and vulnerable (and also a joke), and as such should not have any real information entered into its forms.</p>
<p>Note: No listed products are actually available for sale, do not actually attempt to purchase them. </p>
</center>
</body>
</html>