DROP DATABASE shop;
DROP USER shopadmin;