<?php include "templates/header.php"; ?>
<br>
<center>
<img src="images/welcome-page.png" alt=""></img>
<br>
<a href="inventory.php"><img src="images/view-inventory.png" alt="" border=1 height=100 width=500></img></a>
</center>
<?php include "templates/footer.php"; ?>